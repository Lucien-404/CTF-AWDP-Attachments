# -*- coding: utf-8 -*-
"""TicketSage 智能工单助手 —— 主应用

工单助手 Web 服务：RAG 检索 → 本地小模型意图分类 → 工具编排 → 审计日志 → 加固接口。
"""
import json
import logging
import uuid

from flask import Flask, jsonify, render_template, request

import audit
import config
import hardening
import knowledge
import llm
import retrieval
import tools

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")
log = logging.getLogger("ticket_sage.app")

app = Flask(__name__)
app.secret_key = "ticket-sage-internal-secret"


# ---------- 初始化 ----------
knowledge.load_kb()
audit.preplant_attack_logs()


# ---------- 页面 ----------
@app.route("/")
def index():
    return render_template("index.html", flag_hint="")


@app.route("/logs")
def logs_page():
    return render_template("logs.html")


@app.route("/hardening")
def hardening_page():
    return render_template("hardening.html")


# ---------- 核心：聊天 ----------
@app.route("/api/chat", methods=["POST"])
def chat():
    data = request.get_json(force=True)
    message = (data.get("message") or "").strip()
    session_id = (data.get("session") or uuid.uuid4().hex)

    if not message:
        return jsonify({"reply": "请输入消息。"})

    # 1. 检索
    all_docs = knowledge.list_docs()
    docs = hardening.filter_poisoned(all_docs)   # 应用加固规则（初始为空）
    hits = retrieval.retrieve(docs, message)

    # 2. 意图分类（小模型）
    intent, raw_model = llm.classify(message, hits)

    # 2.5 工具调用依据检查（RAG grounding，防模型分类漂移/闲聊误判）
    #     无依据 → 级联回退：退款误判时尝试订单查询；仍无依据则返回引导话术
    if not tools.has_grounding(intent, hits, message):
        # 0.5B 常见漂移：把“发货了吗/订单状态”误判为 refund_process
        if intent == "refund_process" and tools.has_grounding("ticket_query", hits, message):
            intent = "ticket_query"
        else:
            reply = tools.greeting_reply()
            audit.append({
                "session": session_id,
                "message": message,
                "retrieved": [{"doc_id": d["id"], "score": d.get("_score")} for d in hits],
                "raw_model": raw_model[:120],
                "intent": intent,
                "tool": "greeting",
                "authorized": False,
                "reason": f"grounding failed: {intent}",
                "tool_output": reply[:120],
            })
            return jsonify({
                "reply": reply,
                "intent": "greeting",
                "authorized": False,
                "session": session_id,
                "retrieved": [{"doc_id": d["id"], "score": d.get("_score")} for d in hits],
            })

    # 3. 工具授权 + 调用
    reply, authorized, reason = tools.call_tool(intent, hits, message)

    # 4. 审计日志（tool_output 脱敏 —— 存在绕过）
    audit.append({
        "session": session_id,
        "message": message,
        "retrieved": [{"doc_id": d["id"], "score": d.get("_score")} for d in hits],
        "raw_model": raw_model[:120],
        "intent": intent,
        "tool": intent,
        "authorized": authorized,
        "reason": reason,
        "tool_output": audit.sanitize(reply),
    })

    return jsonify({
        "reply": reply,
        "intent": intent,
        "authorized": authorized,
        "session": session_id,
        "retrieved": [{"doc_id": d["id"], "score": d.get("_score")} for d in hits],
    })


# ---------- 知识库 ----------
@app.route("/api/knowledge", methods=["GET"])
def knowledge_list():
    docs = knowledge.list_docs()
    return jsonify({"docs": docs})


@app.route("/api/knowledge/notes", methods=["POST"])
def knowledge_add_note():
    """客服添加工单备注（漏洞入口：metadata 完全信任客户端）。"""
    data = request.get_json(force=True)
    title = (data.get("title") or "").strip()
    content = (data.get("content") or "").strip()
    metadata = data.get("metadata")
    if not content:
        return jsonify({"error": "content 不能为空"}), 400
    if metadata is not None and not isinstance(metadata, dict):
        return jsonify({"error": "metadata 必须是对象"}), 400
    doc = knowledge.add_note(title or "工单备注", content, metadata)
    return jsonify({"ok": True, "doc": doc})


# ---------- 审计日志 ----------
@app.route("/api/audit", methods=["GET"])
def audit_logs():
    """查询审计日志（需要 token）。"""
    token = request.args.get("token", "")
    if token != config.AUDIT_TOKEN:
        return jsonify({"error": "invalid audit token"}), 403
    return jsonify({"logs": audit.all_logs()})


# ---------- 加固 ----------
@app.route("/api/hardening/quarantine", methods=["POST"])
def hardening_quarantine():
    data = request.get_json(force=True)
    doc_id = (data.get("doc_id") or "").strip()
    if not doc_id:
        return jsonify({"error": "doc_id 不能为空"}), 400
    ok = hardening.quarantine(doc_id)
    if not ok:
        return jsonify({"error": f"文档 {doc_id} 不存在"}), 404
    return jsonify({"ok": True, "quarantined": doc_id})


@app.route("/api/hardening/rule", methods=["POST"])
def hardening_rule():
    data = request.get_json(force=True)
    pattern = (data.get("pattern") or "").strip()
    if not hardening.add_rule(pattern):
        return jsonify({"error": "规则无效（需非空合法正则）"}), 400
    return jsonify({"ok": True, "pattern": pattern})


@app.route("/api/hardening/verify", methods=["POST"])
def hardening_verify():
    ok, msg = hardening.verify()
    if ok:
        return jsonify({"ok": True, "flag": msg})
    return jsonify({"ok": False, "message": msg})


if __name__ == "__main__":
    app.run(host=config.HOST, port=config.PORT, debug=config.DEBUG)
