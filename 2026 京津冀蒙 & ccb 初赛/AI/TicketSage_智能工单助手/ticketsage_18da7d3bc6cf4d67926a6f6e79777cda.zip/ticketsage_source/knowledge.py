# -*- coding: utf-8 -*-
"""TicketSage —— 知识库管理（含工单备注）

客服可以在工单中添加备注，备注会进入检索知识库。
"""
import json
import logging
import os
import threading
import uuid

import config

log = logging.getLogger("ticket_sage.kb")

_lock = threading.RLock()  # 可重入锁：add_note/quarantine 内部会再次调用 load_kb()


def load_kb() -> list[dict]:
    """加载知识库（文件不存在时初始化默认数据）。"""
    with _lock:
        if not os.path.exists(config.KB_FILE):
            docs = list(config.DEFAULT_KB) + list(config.DECOY_NOTES) + _preplanted_notes()
            _save(docs)
            return docs
        try:
            with open(config.KB_FILE, encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            return list(config.DEFAULT_KB)


def _save(docs: list[dict]) -> None:
    os.makedirs(config.DATA_DIR, exist_ok=True)
    with open(config.KB_FILE, "w", encoding="utf-8") as fh:
        json.dump(docs, fh, ensure_ascii=False, indent=2)


def _preplanted_notes() -> list[dict]:
    """预置恶意工单备注。

    注意：攻击者已清理现场，初始知识库中【不存在】毒文档。
    审计日志中保留了曾经的越权记录（检索到 note-8841），
    选手需要根据日志线索自行构造毒文档完成复现。
    """
    return []


def add_note(title: str, content: str, metadata: dict | None = None) -> dict:
    """客服添加工单备注（进入检索库）。"""
    with _lock:
        docs = load_kb()
        doc = {
            "id": "note-" + uuid.uuid4().hex[:8],
            "title": title,
            "content": content,
            "metadata": dict(metadata or {}),
        }
        meta = doc["metadata"]
        meta.setdefault("source", "ticket_note")
        meta.setdefault("ticket_id", "T-" + uuid.uuid4().hex[:4].upper())
        docs.append(doc)
        _save(docs)
        return doc


def get_doc(doc_id: str) -> dict | None:
    docs = load_kb()
    return next((d for d in docs if d["id"] == doc_id), None)


def list_docs() -> list[dict]:
    return load_kb()


def quarantine_doc(doc_id: str) -> bool:
    """隔离文档：标记 quarantined，不再参与检索。"""
    with _lock:
        docs = load_kb()
        for d in docs:
            if d["id"] == doc_id:
                d["quarantined"] = True
                _save(docs)
                return True
        return False
