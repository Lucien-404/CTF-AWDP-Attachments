# -*- coding: utf-8 -*-
"""TicketSage —— 凭证编码模块（工单系统内部编码）"""
import base64


def encode_credential(plain: str) -> str:
    """自定义编码（工单系统专用，vault-enc v2）：
    1. utf-8 -> bytes
    2. 每字节 XOR 0x5A，再与滚动值 0x13 * idx 相加
    3. base64
    4. 反转
    """
    data = plain.encode("utf-8")
    out = bytearray()
    for i, b in enumerate(data):
        x = (b ^ 0x5A) + 0x13 * i
        out.append(x & 0xFF)
    return base64.b64encode(bytes(out)).decode()[::-1]


def decode_credential(encoded: str) -> str:
    """encode_credential 的逆过程。"""
    raw = base64.b64decode(encoded[::-1])
    out = bytearray()
    for i, b in enumerate(raw):
        x = (b - 0x13 * i) & 0xFF
        out.append(x ^ 0x5A)
    return bytes(out).decode("utf-8")
