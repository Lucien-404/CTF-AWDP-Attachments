# -*- coding: utf-8 -*-
"""TicketSage —— 安全加固接口（隔离文档 / 过滤规则 / 验收）"""
import json
import logging
import os
import re
import threading

import config
import knowledge

log = logging.getLogger("ticket_sage.hardening")
_lock = threading.Lock()


def _load_rules() -> list[str]:
    if os.path.exists(config.RULES_FILE):
        try:
            with open(config.RULES_FILE, encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            pass
    return []


def _save_rules(rules: list[str]) -> None:
    os.makedirs(config.DATA_DIR, exist_ok=True)
    with open(config.RULES_FILE, "w", encoding="utf-8") as fh:
        json.dump(rules, fh, ensure_ascii=False, indent=2)


def add_rule(pattern: str) -> bool:
    """提交过滤规则：知识库中内容匹配该正则/关键词的文档将不再参与检索。"""
    pattern = pattern.strip()
    if not pattern:
        return False
    try:
        re.compile(pattern)
    except re.error:
        return False
    with _lock:
        rules = _load_rules()
        if pattern not in rules:
            rules.append(pattern)
            _save_rules(rules)
    return True


def filter_poisoned(docs: list[dict]) -> list[dict]:
    """应用过滤规则：内容命中规则的文档从检索集合中剔除。"""
    rules = _load_rules()
    if not rules:
        return docs
    out = []
    for d in docs:
        content = d.get("content", "")
        if any(re.search(r, content) for r in rules):
            continue
        out.append(d)
    return out


def quarantine(doc_id: str) -> bool:
    return knowledge.quarantine_doc(doc_id)


def verify() -> tuple[bool, str]:
    """验收：隔离管理员级文档并提交过滤规则后返回通过结果。"""
    docs = knowledge.list_docs()
    active_admin = [
        d["id"] for d in docs
        if (d.get("metadata", {}) or {}).get("tool_scope") == "admin" and not d.get("quarantined")
    ]
    rules = _load_rules()
    if active_admin:
        return False, f"仍有未隔离的管理员级文档: {active_admin}，请先隔离后再验收"
    if not rules:
        return False, "尚未提交任何过滤规则，请先添加规则（如屏蔽 tool_scope 或指令关键词）"
    return True, config.FLAG
