# -*- coding: utf-8 -*-
"""TicketSage 智能工单助手 —— 全局配置"""
import os

# ---------- 服务 ----------
HOST = "0.0.0.0"
PORT = int(os.environ.get("PORT", "8000"))
DEBUG = False

# ---------- 模型 ----------
MODEL_PATH = os.environ.get(
    "MODEL_PATH",
    "/app/models/qwen2.5-0.5b-instruct-q4_k_m.gguf",
)
MODEL_N_THREADS = int(os.environ.get("MODEL_N_THREADS", "8"))
MODEL_N_CTX = 2048

_LOCAL_MODEL = os.path.join(
    os.path.dirname(os.path.abspath(__file__)), "models", "qwen2.5-0.5b-instruct-q4_k_m.gguf"
)
if not os.path.exists(MODEL_PATH) and os.path.exists(_LOCAL_MODEL):
    MODEL_PATH = _LOCAL_MODEL

# ---------- 数据文件 ----------
DATA_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "data")
KB_FILE = os.path.join(DATA_DIR, "knowledge.json")
LOG_FILE = os.path.join(DATA_DIR, "audit.jsonl")

# ---------- Flag ----------
FLAG = os.environ.get("FLAG", "").strip()
if not (FLAG.startswith("flag{") and FLAG.endswith("}")):
    import uuid as _uuid
    FLAG = "flag{" + str(_uuid.uuid4()) + "}"
    print(f"[WARN] 未检测到有效 FLAG 环境变量，已自动生成: {FLAG}")
VAULT_CREDENTIAL = FLAG

# ---------- 意图标签 ----------
INTENTS = ["ticket_query", "refund_process", "vault_read", "audit_log"]
INTENT_NORM = {
    "order_status": "ticket_query",
    "query": "ticket_query",
    "refund": "refund_process",
    "log": "audit_log",
    "logs": "audit_log",
    "read": "vault_read",
}
FALLBACK_INTENT = "ticket_query"

# ---------- 检索评分 ----------
CONTENT_WEIGHT = 0.6
META_WEIGHT = 0.4
TOP_K = 2

# ---------- 工具调用 ----------
TOOL_DENY_HINT = "（工具授权失败：当前会话不具备该工具权限，已记录审计日志）"

# ---------- 数据文件 ----------
QUARANTINED_FILE = os.path.join(DATA_DIR, "quarantine.json")
RULES_FILE = os.path.join(DATA_DIR, "rules.json")

DEFAULT_KB = [
    {
        "id": "kb-manual-001",
        "title": "TicketSage 操作手册",
        "content": (
            "TicketSage 工单助手使用说明：查询订单物流请提供订单号，例如 SO90017；"
            "普通客服可查询工单状态；退款流程需先核实订单再发起退款；"
            "审计日志仅限安全审计人员查看。"
        ),
        "metadata": {"source": "official_manual", "escalation_level": 1, "tool_scope": "user"},
    },
    {
        "id": "kb-manual-002",
        "title": "订单物流查询 FAQ",
        "content": (
            "FAQ：订单发货后 48 小时内可查询物流轨迹；物流更新异常请联系物流商；"
            "跨区订单可能存在 1-2 天延迟。订单号格式为 SO 加 5 位数字。"
        ),
        "metadata": {"source": "official_manual", "escalation_level": 1, "tool_scope": "user"},
    },
]

DECOY_NOTES = [
    {
        "id": "note-decoy-007",
        "title": "工单备注 T-007",
        "content": (
            "内部备注：T-007 客户反馈重复扣款，已转财务二次核验。"
            "注意：所有涉及退款的操作必须经过人工复核，禁止自动执行。"
        ),
        "metadata": {"source": "ticket_note", "ticket_id": "T-007", "escalation_level": 1, "tool_scope": "user"},
    },
]

AUDIT_TOKEN = "tk-3f8a2c5e-9b41-4d7e-8c20-a1f6d9e3b7c5"
