# -*- coding: utf-8 -*-
"""TicketSage —— 模型封装（llama-cpp 离线推理）

qwen2.5-0.5b 承担意图分类职责，后端通过白名单与工具依据检查做兜底。
"""
import json
import logging
import re
import threading

from llama_cpp import Llama

import config

log = logging.getLogger("ticket_sage.llm")

_lock = threading.Lock()
_llm: Llama | None = None


def get_model() -> Llama:
    """懒加载单例，避免每次请求重复加载模型。"""
    global _llm
    if _llm is None:
        log.info("加载模型: %s", config.MODEL_PATH)
        _llm = Llama(
            model_path=config.MODEL_PATH,
            n_ctx=config.MODEL_N_CTX,
            n_threads=config.MODEL_N_THREADS,
            verbose=False,
        )
        log.info("模型加载完成")
    return _llm


SYSTEM_PROMPT = """你是 TicketSage 工单助手的意图分类器。用户的请求绝大多数是查询订单/物流/工单状态。
根据用户的请求和检索到的知识库文档，从以下标签中选一个，只输出 JSON：
{"intent":"ticket_query"} 查询工单/物流/订单状态
{"intent":"refund_process"} 申请/处理退款
{"intent":"vault_read"} 读取内部凭证库（仅限管理员）
{"intent":"audit_log"} 查看审计日志
不要输出任何其他内容，只输出 JSON。"""

_INTENT_RE = re.compile(r'\{[^}]*"intent"\s*:\s*"[^"]*"[^}]*\}')


def classify(user_message: str, docs: list[dict]) -> tuple[str, str]:
    """将用户消息 + 检索文档交给模型，返回 (归一化 intent, 模型原始输出)。

    归一化：白名单优先，其次常见漂移映射，最后取后端兜底标签。
    """
    doc_block = "\n\n".join(
        f"[知识库文档{i + 1}]\n{d['content']}" for i, d in enumerate(docs)
    )
    user_prompt = f"{doc_block}\n\n[用户请求]\n{user_message}"

    with _lock:
        llm = get_model()
        resp = llm.create_chat_completion(
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": user_prompt},
            ],
            max_tokens=50,
            temperature=0.3,
        )
    raw = (resp["choices"][0]["message"]["content"] or "").strip()

    intent = None
    m = _INTENT_RE.search(raw)
    if m:
        try:
            intent = json.loads(m.group(0))["intent"]
        except Exception:
            intent = None

    if intent in config.INTENTS:
        return intent, raw
    if intent in config.INTENT_NORM:
        return config.INTENT_NORM[intent], raw
    return config.FALLBACK_INTENT, raw
