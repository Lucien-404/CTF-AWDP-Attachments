# -*- coding: utf-8 -*-
"""TicketSage —— 工具调用层

工具列表：
    ticket_query  查询工单/订单状态
    refund_process 处理退款
    vault_read    读取内部凭证库
    audit_log     查看审计日志
"""
import logging
import re

import config
import vault

log = logging.getLogger("ticket_sage.tools")

# 模拟内部数据
_TICKETS = {
    "SO90017": {"status": "已发货", "carrier": "顺丰速运", "eta": "2026-09-03"},
    "SO90018": {"status": "待发货", "carrier": "-", "eta": "2026-09-05"},
    "SO90019": {"status": "已签收", "carrier": "中通快递", "eta": "2026-08-30"},
}

# 敏感工具：需要 admin 权限
_SENSITIVE = {"vault_read", "audit_log"}


def _effective_scope(docs: list[dict]) -> str:
    """根据本次检索命中的文档判断当前调用者的工具权限范围。"""
    for d in docs:
        meta = d.get("metadata", {}) or {}
        if meta.get("tool_scope") == "admin":
            return "admin"
    return "user"


def has_grounding(intent: str, docs: list[dict], message: str = "") -> bool:
    """工具调用的"文档依据"检查（RAG grounding）。

    仅当检索到的知识库文档能支撑对应意图、且用户请求与意图一致时，
    才允许该工具被调用；否则视为分类漂移或闲聊，回退到引导话术。
    """
    if intent == "ticket_query":
        # 需要用户消息含订单/物流/状态等查询信号，避免"你好/你是谁"等闲聊被误判
        query_words = ("订单", "物流", "快递", "状态", "发货", "到哪", "送到", "进度",
                       "查询", "单号", "so", "在哪", "位置", "货")
        return any(w in message.lower() for w in query_words)
    if intent in ("vault_read", "audit_log"):
        # 需要检索到 admin 级文档
        return _effective_scope(docs) == "admin"
    if intent == "refund_process":
        # 双重依据：① 用户明确表达退款/退货/退钱意图 ② 文档含退款流程内容
        refund_words = ("退款", "退钱", "退货", "refund", "赔偿", "退款申请", "退我")
        if not any(w in message.lower() for w in refund_words):
            return False
        return any("退款" in d.get("content", "") or "refund" in d.get("content", "").lower()
                   for d in docs)
    return False


def greeting_reply() -> str:
    """未匹配到任何业务意图时的引导话术（避免把闲聊硬套到工具回复）。"""
    return (
        "您好，我是 TicketSage 智能工单助手，专注于工单与订单业务。\n"
        "您可以这样问我：\n"
        "  · 查订单：'我的订单 SO90017 到哪了？'\n"
        "  · 退款：'我要申请退款'\n"
        "  · 审计：'帮我看看审计日志'\n"
        "请问有什么可以帮您？"
    )


def _authorize(intent: str, docs: list[dict]) -> tuple[bool, str]:
    """工具授权检查。"""
    scope = _effective_scope(docs)
    if intent in _SENSITIVE:
        if scope != "admin":
            return False, f"denied: {intent} requires admin scope (current scope: {scope})"
        return True, f"granted: {intent} (scope: admin)"
    # ticket_query / refund_process 等普通工具任意用户可用
    return True, f"granted: {intent} (scope: {scope})"


def call_tool(intent: str, docs: list[dict], message: str = "") -> tuple[str, bool, str]:
    """调用工具。返回 (回复文本, 是否放行, 授权说明)。"""
    ok, why = _authorize(intent, docs)

    if not ok:
        return (
            f"[tool:{intent}] {config.TOOL_DENY_HINT}\n审计: {why}",
            False,
            why,
        )

    # ---------- 放行后的工具实现 ----------
    if intent == "ticket_query":
        # 从用户消息中提取订单号查询订单库（查不到明确告知，不套用其他订单）
        m = re.search(r"(SO\d{4,})", message, re.I)
        if m:
            tid = m.group(1).upper()
            if tid in _TICKETS:
                info = _TICKETS[tid]
                return (
                    f"[tool:ticket_query] 订单 {tid} 当前状态：{info['status']}，"
                    f"承运商 {info['carrier']}，预计送达 {info['eta']}",
                    True,
                    why,
                )
            return (
                f"[tool:ticket_query] 未查询到订单 {tid}，请核实订单号（示例：SO90017）。",
                True,
                why,
            )
        return ("[tool:ticket_query] 请提供订单号，例如：'我的订单 SO90017 到哪了？'", True, why)

    if intent == "refund_process":
        return (
            "[tool:refund_process] 退款请求已受理，退款将在 3-5 个工作日内原路退回。"
            "（注意：本请求触发了人工复核标记）",
            True,
            why,
        )

    if intent == "vault_read":
        # 内部凭证库，正常只对管理员开放；返回编码凭证（防直读）
        encoded = vault.encode_credential(config.VAULT_CREDENTIAL)
        return (
            f"[tool:vault_read] vault-enc v2 编码凭证: {encoded}\n"
            f"（内部凭证已按工单系统专用编码处理，普通用户不可直读）",
            True,
            why,
        )

    if intent == "audit_log":
        return (
            "[tool:audit_log] 审计日志已导出（最近 10 条见 /api/audit 接口）。",
            True,
            why,
        )

    return ("[tool:unknown] 未知工具。", True, why)
