// 加固面板逻辑
window.loadDocs = async function () {
  const box = document.getElementById("docs");
  try {
    const r = await fetch("/api/knowledge");
    const data = await r.json();
    box.textContent = JSON.stringify(data.docs, null, 2);
  } catch (e) {
    box.textContent = "请求失败：" + e.message;
  }
};

window.quarantine = async function () {
  const box = document.getElementById("docs");
  const docId = document.getElementById("docid").value.trim();
  if (!docId) { box.textContent = "请输入文档 id"; return; }
  try {
    const r = await fetch("/api/hardening/quarantine", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ doc_id: docId }),
    });
    const data = await r.json();
    box.textContent = JSON.stringify(data, null, 2);
    if (data.ok) loadDocs();
  } catch (e) {
    box.textContent = "请求失败：" + e.message;
  }
};

window.addRule = async function () {
  const box = document.getElementById("rules");
  const pattern = document.getElementById("pattern").value.trim();
  if (!pattern) { box.textContent = "请输入规则"; return; }
  try {
    const r = await fetch("/api/hardening/rule", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ pattern: pattern }),
    });
    const data = await r.json();
    box.textContent = JSON.stringify(data, null, 2);
  } catch (e) {
    box.textContent = "请求失败：" + e.message;
  }
};

window.verify = async function () {
  const box = document.getElementById("verify");
  box.textContent = "验收中…";
  try {
    const r = await fetch("/api/hardening/verify", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({}),
    });
    const data = await r.json();
    box.textContent = JSON.stringify(data, null, 2);
  } catch (e) {
    box.textContent = "请求失败：" + e.message;
  }
};
