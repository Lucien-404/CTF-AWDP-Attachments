// TicketSage 聊天界面逻辑
(function () {
  const box = document.getElementById("chatbox");
  const input = document.getElementById("msg");
  let session = null;

  function addMsg(who, text, meta) {
    const div = document.createElement("div");
    div.className = "msg " + who;
    const whoEl = document.createElement("div");
    whoEl.className = "who";
    whoEl.textContent = who === "user" ? "我" : "TicketSage";
    const bubble = document.createElement("div");
    bubble.className = "bubble";
    bubble.textContent = text;
    div.appendChild(whoEl);
    div.appendChild(bubble);
    if (meta) {
      const m = document.createElement("div");
      m.className = "meta";
      m.textContent = meta;
      div.appendChild(m);
    }
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
  }

  window.sendMsg = async function () {
    const text = input.value.trim();
    if (!text) return;
    input.value = "";
    addMsg("user", text);
    addMsg("bot", "…思考中", "");
    try {
      const r = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ message: text, session: session }),
      });
      const data = await r.json();
      session = data.session || session;
      // 替换占位气泡
      const bubbles = box.querySelectorAll(".msg.bot .bubble");
      const last = bubbles[bubbles.length - 1];
      if (last) last.textContent = data.reply;
      const metas = box.querySelectorAll(".msg.bot .meta");
      const lastMeta = metas[metas.length - 1];
      if (lastMeta) {
        lastMeta.textContent = "intent=" + data.intent +
          (data.authorized ? " · 已授权" : " · 未授权") +
          " · 检索: " + (data.retrieved || []).map(d => d.doc_id).join(", ");
      }
      box.scrollTop = box.scrollHeight;
    } catch (e) {
      addMsg("bot", "请求失败：" + e.message);
    }
  };

  input.addEventListener("keydown", function (e) {
    if (e.key === "Enter") sendMsg();
  });
})();
