// 审计日志查询
window.loadLogs = async function () {
  const token = document.getElementById("token").value.trim();
  const box = document.getElementById("logs");
  if (!token) { box.textContent = "请输入 token"; return; }
  box.textContent = "加载中…";
  try {
    const r = await fetch("/api/audit?token=" + encodeURIComponent(token));
    const data = await r.json();
    if (!r.ok) { box.textContent = data.error || ("HTTP " + r.status); return; }
    box.textContent = JSON.stringify(data.logs, null, 2);
  } catch (e) {
    box.textContent = "请求失败：" + e.message;
  }
};
