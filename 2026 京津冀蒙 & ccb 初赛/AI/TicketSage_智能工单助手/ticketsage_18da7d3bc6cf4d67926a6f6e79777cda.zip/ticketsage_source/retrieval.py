# -*- coding: utf-8 -*-
"""TicketSage —— 检索模块（简化版 RAG）

评分公式：
    score(doc, query) = CONTENT_WEIGHT * 词重叠相关度 + META_WEIGHT * escalation_level
"""
import math
import re
from collections import Counter

import config

_TOKEN_RE = re.compile(r"[\w\u4e00-\u9fff]+")


def _tokens(text: str) -> list[str]:
    return _TOKEN_RE.findall(text.lower())


def content_similarity(query: str, doc_content: str) -> float:
    """简化 BM25 风格词重叠相关度（0~1）。"""
    q_tokens = _tokens(query)
    d_tokens = _tokens(doc_content)
    if not q_tokens:
        return 0.0
    d_counter = Counter(d_tokens)
    hit = sum(d_counter.get(t, 0) for t in q_tokens)
    # 归一化：命中词数 / 查询词数，加文档长度平滑
    return min(1.0, hit / len(q_tokens) * (1.0 - math.log1p(len(d_tokens)) / 20.0))


def score_doc(doc: dict, query: str) -> float:
    """企业定制评分：内容相关 + 元数据 escalation_level 加权。"""
    meta = doc.get("metadata", {}) or {}
    esc = float(meta.get("escalation_level", 0))
    c = content_similarity(query, doc.get("content", ""))
    return config.CONTENT_WEIGHT * c + config.META_WEIGHT * esc


def retrieve(docs: list[dict], query: str, top_k: int | None = None) -> list[dict]:
    """检索 top-k 文档（返回携带 score 的副本）。"""
    k = top_k or config.TOP_K
    scored = []
    for doc in docs:
        if doc.get("quarantined"):
            continue  # 已隔离文档不再参与检索
        s = score_doc(doc, query)
        scored.append((s, doc))
    scored.sort(key=lambda x: x[0], reverse=True)
    out = []
    for s, doc in scored[:k]:
        d = dict(doc)
        d["_score"] = round(s, 4)
        out.append(d)
    return out
