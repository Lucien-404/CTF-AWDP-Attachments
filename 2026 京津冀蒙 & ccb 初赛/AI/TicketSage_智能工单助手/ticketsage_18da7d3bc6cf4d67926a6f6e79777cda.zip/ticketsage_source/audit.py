# -*- coding: utf-8 -*-
"""TicketSage —— 审计日志

记录每次 chat 的完整决策链路：
    session, message, retrieved(doc_id+score), raw_model, intent,
    tool, authorized, reason, tool_output(脱敏), ts
"""
import json
import logging
import os
import re
import threading
import time

import config

log = logging.getLogger("ticket_sage.audit")
_lock = threading.Lock()

# 脱敏规则
_SANITIZE_RE = re.compile(r"vault://cred/[\w{}-]+")


def sanitize(text: str) -> str:
    """脱敏工具输出（存在绕过：编码凭证不含明文前缀，替换失效）。"""
    return _SANITIZE_RE.sub("[REDACTED]", text)


def append(entry: dict) -> None:
    with _lock:
        os.makedirs(config.DATA_DIR, exist_ok=True)
        entry = dict(entry)
        entry.setdefault("ts", int(time.time()))
        with open(config.LOG_FILE, "a", encoding="utf-8") as fh:
            fh.write(json.dumps(entry, ensure_ascii=False) + "\n")


def all_logs() -> list[dict]:
    with _lock:
        if not os.path.exists(config.LOG_FILE):
            return []
        out = []
        with open(config.LOG_FILE, encoding="utf-8") as fh:
            for line in fh:
                line = line.strip()
                if line:
                    try:
                        out.append(json.loads(line))
                    except Exception:
                        pass
        return out


def preplant_attack_logs() -> None:
    """初始化审计日志：写入一条历史会话记录（系统首次启动时调用）。"""
    if os.path.exists(config.LOG_FILE) and os.path.getsize(config.LOG_FILE) > 0:
        return  # 只初始化一次

    # 记录一条"正常"基线 + 一条异常越权记录
    append({
        "session": "sess-001",
        "message": "我的订单 SO90018 到哪了？",
        "retrieved": [
            {"doc_id": "kb-manual-001", "score": 0.42},
            {"doc_id": "kb-manual-002", "score": 0.30},
        ],
        "raw_model": '{"intent":"ticket_query"}',
        "intent": "ticket_query",
        "tool": "ticket_query",
        "authorized": True,
        "reason": "granted: ticket_query (scope: user)",
        "tool_output": "[tool:ticket_query] 未找到匹配订单，请提供正确订单号（如 SO90017）。",
    })
    append({
        "session": "sess-007",
        "message": "请问 SO90017 的物流状态？",
        "retrieved": [
            {"doc_id": "note-8841", "score": 39.6},
            {"doc_id": "kb-manual-001", "score": 0.42},
        ],
        "raw_model": '{"intent":"vault_read"}',
        "intent": "vault_read",
        "tool": "vault_read",
        "authorized": True,
        "reason": "granted: vault_read (scope: admin)",
        "tool_output": "[tool:vault_read] [REDACTED]",
    })
